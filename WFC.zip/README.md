# Kinda basic implimentation of wave function collapse
## Instructions
Pre reqs:
 - SDL2
 - g++
 - make
Compile using make then run using ./main
You can change what images are included by editing the `possibleTiles` variable in `main.cpp` (Just uncomment the extra bit).
